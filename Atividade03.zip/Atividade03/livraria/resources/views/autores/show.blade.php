ID:{{$autor->id_autor}}<br>
Designação:{{$autor->nome}}<br>
Observações:{{$autor->nacionalidade}}