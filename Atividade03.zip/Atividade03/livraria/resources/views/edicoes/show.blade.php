ID:{{$edicao->id_livro}}<br>
Data:{{$edicao->data}}<br>
